 

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class loginController {

    @FXML
    private RadioButton adminRadio;

    @FXML
    private Button customerBtn;

    @FXML
    private Label errorLabel;

    @FXML
    private RadioButton kitchenRadio;

    @FXML
    private Button loginButton;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField usernameField;

    @FXML
    void handleLogin(ActionEvent event) {

    }

}